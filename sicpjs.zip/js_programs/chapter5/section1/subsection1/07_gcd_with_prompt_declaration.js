const gcd_with_prompt_controller =
