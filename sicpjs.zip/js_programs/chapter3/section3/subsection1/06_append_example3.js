list_ref(append(list(1, 3), list(5, 7, 9)), 4);

// expected: 9
