function make_queue() { return pair(null, null); }
const q1 = make_queue();
