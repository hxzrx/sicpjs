stream_ref(ones, 50);
