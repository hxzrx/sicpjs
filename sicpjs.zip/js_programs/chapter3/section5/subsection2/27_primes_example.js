stream_ref(primes, 50);
