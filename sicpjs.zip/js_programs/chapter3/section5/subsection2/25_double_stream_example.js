stream_ref(double, 50);
