head(stream_tail(pair(4, () => pair(5, () => null))));
