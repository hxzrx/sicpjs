deriv("x", "x");
// 1
