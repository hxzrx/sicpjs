head(tail(head(tail(deriv(list("*", list("*", "x", "y"), list("+", "x", 3)), "x")))));
